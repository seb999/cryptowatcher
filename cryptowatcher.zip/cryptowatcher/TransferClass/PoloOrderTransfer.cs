﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cryptowatcher.TransferClass
{
    public class PoloOrderTransfer
    {
        public string AskPrice { get; set; }

        public string AskQuantity { get; set; }

        public string BidPrice { get; set; }

        public string BidQuantity { get; set; }
    }
}
