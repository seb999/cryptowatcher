import {IFilter} from "../interfaces/iFilter";

// deprecated, use iFilter
export interface Filter extends IFilter {
}
