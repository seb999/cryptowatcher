<!--- Provide a general summary of the issue in the Title above -->
## Link to jsfiddle showing the issue.
<!--- This is by far the most important bit! -->
<!--- Fork this http://jsfiddle.net/gh/get/jquery/3.1.1/pablojim/highcharts-ng/tree/master/jsfiddles/basic/ ? -->

## Expected Behaviour
<!--- If you're describing a bug, tell us what should happen -->
<!--- If you're suggesting a change/improvement, tell us how it should work -->

## Current Behaviour
<!--- If describing a bug, tell us what happens instead of the expected behaviour -->
<!--- If suggesting a change/improvement, explain the difference from current behaviour -->

## Your Environment
<!--- Include as many relevant details about the environment you experienced the bug in -->
* Version of highcharts-ng used:
* Browser Name and version:
* Operating System and version (desktop or mobile):
* Link to your project:
