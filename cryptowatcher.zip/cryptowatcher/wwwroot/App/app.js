﻿
// create your module with ag-Grid as a dependency
var myApp = angular.module('MyApp', ['ui.bootstrap', 'ui.grid', 'highcharts-ng']);

// myApp.run(['$templateCache', function ( $templateCache ) {
//     alert();
//     $templateCache.removeAll(); }]);